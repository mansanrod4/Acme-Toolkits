package notenoughspam.detector;

import java.util.Arrays;

import notenoughspam.utils.StringUtils;

public class SpamDetector {

	private final Double strongSpamThreshold;
	private final Double weakSpamThreshold;
	private final String[] strongSpamWords;
	private final String[] weakSpamWords;
	 
	
	public SpamDetector(final Double strongSpamThreshold, final Double weakSpamThreshold, final String[] strongSpamWords, final String[] weakSpamWords) {
		this.strongSpamThreshold = strongSpamThreshold;
		this.weakSpamThreshold = weakSpamThreshold;
		this.strongSpamWords = strongSpamWords;
		this.weakSpamWords = weakSpamWords;
	}
	
	public boolean stringHasStrongSpam(final String string) {
		final Integer countStrongSpam = Arrays.stream(this.strongSpamWords).mapToInt(w-> StringUtils.countSubstring(string, w)).sum();
		final Integer numberOfWords = string.split(" ").length;
		final double ratio = countStrongSpam.doubleValue()/numberOfWords.doubleValue();
		final boolean res = (ratio)>(this.strongSpamThreshold/100.0);
		System.out.println("StrongSpam: "+countStrongSpam+", "+numberOfWords+", "+ratio+", "+this.strongSpamThreshold+", "+res);

		return res;
	}
	
	public boolean stringHasWeakSpam(final String string) {
		final Integer countWeakSpam = Arrays.stream(this.weakSpamWords).mapToInt(w-> StringUtils.countSubstring(string, w)).sum();
		final Integer numberOfWords = string.split(" ").length;
		final double ratio = countWeakSpam.doubleValue()/numberOfWords.doubleValue();

		final boolean res = (ratio)>(this.weakSpamThreshold/100.0);
		System.out.println("WeakSpam: "+countWeakSpam+", "+numberOfWords+", "+ratio+", "+this.weakSpamThreshold+", "+res);

		return res;
	}
		
	public Boolean stringHasNoSpam(final String string) {
		
		return !(this.stringHasStrongSpam(string) || this.stringHasWeakSpam(string));
	}
	
}